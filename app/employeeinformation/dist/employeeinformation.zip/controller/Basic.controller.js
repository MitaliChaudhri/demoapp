sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("employeeinformation.controller.Basic",{onInit:function(){}})});
//# sourceMappingURL=Basic.controller.js.map